const questions = [
  "What is a class in Java?",
  "Explain OOP concepts.",
  "What is a linked list?"
];
let current = 0;
function nextQuestion() {
  document.getElementById("question").innerText = questions[current];
  current = (current + 1) % questions.length;
}
let timer = 10;
setInterval(() => {
  document.getElementById("time").innerText = timer--;
  if (timer < 0) timer = 10;
}, 1000);

# Interview Questions Website

This is a multi-feature interview preparation website built with:
- 🎤 Voice-to-text input
- 🧠 Problem-solving videos
- ⏲️ Timed animated quiz

## Pages
- `index.html` – Home page with navigation
- `quiz.html` – Practice questions with timer
- `voice.html` – Convert your speech to text for answers
- `videos.html` – YouTube embedded learning content

## How to Run
Open `index.html` in your browser. Best viewed on desktop.

---
Created by Subasri S 💻
